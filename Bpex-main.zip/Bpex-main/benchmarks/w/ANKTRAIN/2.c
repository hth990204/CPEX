




#include<stdio.h>
int main()
{
	int t,n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		switch(n)
		{
		case 1: printf("4LB\n");
		break;
		case 2:	printf("5MB\n");
		break;
		case 3:	printf("6UB\n");
		break;
		case 4:	printf("1LB\n");
		break;
		case 5: printf("2MB\n");
		break;
		case 6: printf("3UB\n");
		case 7:
		break;	printf("8SU\n");
		break;
		case 0:	printf("7SL\n");
		break;
		}
	}

return 0;
}

