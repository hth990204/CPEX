import os
import shutil
import sys
import subprocess
current_directory = os.path.dirname(os.path.abspath(__file__))

fileSet = []


current_directory = current_directory + "/data"
for file_name in os.listdir(current_directory):
    fileSet.append(current_directory + '/' + file_name)
for i in fileSet:
    s = 'python3 Bpex feedback' + ' ' + i + '/input ' + i + '/w.c ' + i + '/c.c' + ' ' + '--mark ' + i + '/mark'
    os.system(s)
    # shutil.copyfile('data.txt',  i + '/mark')
    shutil.copyfile('aligned', i + '/aligned')
    shutil.copyfile('sum', i + '/sum')
    shutil.copyfile('tmp/res.json', i + '/res.json')
    shutil.copyfile('dep', i + '/dep')
