import os
import shutil
import sys
import subprocess
current_directory = os.path.dirname(os.path.abspath(__file__))

fileSet = []


current_directory = current_directory + "/data"
for file_name in os.listdir(current_directory):
    fileSet.append(current_directory + '/' + file_name)
# fileSet.append(current_directory + '/' + 'MISSP')

for i in fileSet:
    with open(i + '/mark', 'r') as f:
        data = f.read()
        data = data[1:-1]
        data_list = data.split(',')
        with open(i + '/countMark', "w") as w:
            w.write(str((len(data_list))))

