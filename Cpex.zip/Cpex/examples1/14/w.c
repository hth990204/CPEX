#include <stdio.h>

int main(void) {
	// your code goes here
	int t,n,i,m,k,z,flag=0;
	scanf("%d",&t);
	while(t--)
	{
	    scanf("%d",&n);
	    int arr[n];
	    for(i=0;i<n;i++)
	    {
	        scanf("%d",&arr[i]);
	    }
	    int j;
	    for(j=0;j<n;j++)
	    {
	        m=arr[j];
	        for(k=0;k<n;k++){
	            if(m==arr[k] && k!=j)
	            {
	                flag=0;
	            }
	            else
	            {
	                flag=1;
	                break;

	            }
	            printf("%d",m);
	        }
	    }
	}
	return 0;
}
