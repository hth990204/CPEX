f = open("../TRISQ/mark", "r")
alllines = f.readlines()
f.close()
f = open("../TRISQ/mark", "w+")
for eachline in alllines:
    string = eachline.replace(',', ', ')
    f.writelines(string)
f.close()

