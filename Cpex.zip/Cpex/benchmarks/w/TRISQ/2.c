




#include <stdio.h>

int main(void) {
	// your code goes here
	int i,t,b;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	  scanf("%d",&b);
	  printf("%d\n",(b*b)/16);
	
	return 0;
}



