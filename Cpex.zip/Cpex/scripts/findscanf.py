
from common import *

from itertools import product
import time

def find_scanf(parama, paramb):


    list_value = []

    scanf_list = []

    ss = parama.exec.exec
    for key, value in ss.items():
        list_value.append(value)
    listOPA = [I for I in list_value if isinstance(I, OPIns) and not isinstance(I, LDIns) and I.src != None and "scanf" in I.src]
    listBBA = [I for I in listOPA if I.cdep.src == None or isinstance(I.cdep, BRIns)]
    listBBA = list(set(listBBA))

    listBBA.sort(key = lambda x: (x.vid, x.vii))

    list_value = []
    ss = paramb.exec.exec
    for key, value in ss.items():
        list_value.append(value)

    listOPB = [I for I in list_value if
               isinstance(I, OPIns) and not isinstance(I, LDIns) and I.src != None and "scanf" in I.src]
    listBBB = [I for I in listOPB if I.cdep.src == None or isinstance(I.cdep, BRIns)]
    listBBB = list(set(listBBB))

    listBBB.sort(key=lambda x: (x.vid, x.vii))
    for i in range(len(listBBA)):
        scanf_list.append([listBBA[i], listBBB[i]])
    return scanf_list