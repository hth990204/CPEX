from common import *

def find_print(parama, paramb):

    listPRA = parama.printins
    listPRB = paramb.printins

    print_list = []
    len1 = len(listPRA)
    len2 = len(listPRB)

    for i in range(min(len1, len2)):
        print_list.append([listPRA[i], listPRB[i]])
    return print_list

