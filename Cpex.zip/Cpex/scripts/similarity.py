
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

def find_similarity(sectenceA, sentenceB):
    combination = [sectenceA, sentenceB]
    embeddings = model.encode(combination)
    similarity = util.cos_sim(embeddings[0], embeddings[1])
    return similarity

def edit_distance(sectenceA, sentenceB):
            n = len(sectenceA)
            m = len(sentenceB)
            # 有一个字符串为空串
            if n * m == 0:
                return n + m

            # DP 数组
            D = [[0] * (m + 1) for _ in range(n + 1)]

            # 边界状态初始化
            for i in range(n + 1):
                D[i][0] = i
            for j in range(m + 1):
                D[0][j] = j

            # 计算所有 DP 值
            for i in range(1, n + 1):
                for j in range(1, m + 1):
                    left = D[i - 1][j] + 1
                    down = D[i][j - 1] + 1
                    left_down = D[i - 1][j - 1]
                    if sectenceA[i - 1] != sentenceB[j - 1]:
                        left_down += 1
                    D[i][j] = min(left, down, left_down)

            return 2*D[n][m]/(m + n)
