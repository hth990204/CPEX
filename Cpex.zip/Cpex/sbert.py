import json
import time

from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('paraphrase-MiniLM-L6-v2')


record = time.thread_time()
sentences1 = []
sentences2 = []
sentences = []
with open('data.json', 'r') as f:
    data = json.load(f)

for i in data:
    src1 = i['src1']
    src2 = i['src2']
    sentences1.append(src1)
    sentences2.append(src2)

for i in zip(sentences1, sentences2):
  sentences.append([i[0], i[1]])

for i in sentences:
  embeddings = model.encode(i)
  similarity = util.cos_sim(embeddings[0], embeddings[1])
  if similarity < 0.7:
      print(i)
  print(similarity)

print(time.thread_time() - record)