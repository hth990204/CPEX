#include<stdio.h>
#include<stdlib.h>


int queue[64][3]; // 队列，用于存储未访问的马位置
int front = 0;          // 队首索引
int rear = 0;           // 队尾索引

// 检查某个点是否合法
int isValid(int x, int y)
{
    if (x >= 0 && x < 8 && y >= 0 && y < 8) {
        return 1;
    }
    return 0;
}

// 对于当前位置，将可能到达的下一个位置添加到队列尾部
void enqueue(int x, int y, int step)
{
    if(isValid(x, y)) {
        queue[rear][0] = x;
        queue[rear][1] = y;
        queue[rear][2] = step;  // 记录走到当前点的步数
        rear++;
    }
}

// 从队首取出一个点
void dequeue(int *x, int *y, int *step)
{
    *x = queue[front][0];
    *y = queue[front][1];
    *step = queue[front][2];
    front++;
}

// 检查这个点是否为终点
int isEnd(int x, int y, int tarx, int tary)
{
    if(x == tarx && y == tary) {
        return 1;
    }
    return 0;
}

// 广度优先搜索，求解最短路径长度
int bfs(int x, int y, int tarx, int tary)
{
    int destins[8][2] = {{+2, +1}, {+2, -1}, {+1, +2}, {+1 ,-2}, {-2, -1}, {-2, +1}, {-1, +2}, {-1, -2}};  // 马可能到达的下一个位置
    int visited[8][8];   // 标记哪些点已访问过
    int step = 0;

    enqueue(x, y, step);    // 将起点加入队列

    while (front < rear) {  // 只要队列不为空，就一直循环
        int nowX;
        int nowY;

        dequeue(&nowX, &nowY, &step);  // 取出一个点

        if(isEnd(nowX, nowY, tarx, tary)){
            return step;
        }

        // 将该点能够到达的所有点添加到队列中
        for (int i = 0; i < 8; i++) {
            int nextX = nowX + destins[i][0];
            int nextY = nowY + destins[i][1];
            if (!visited[nextX][nextY]) {
                visited[nextX][nextY] = 1;  // 标记该点已经访问过
                enqueue(nextX, nextY, step+1);
            }
        }
    }

    return -1;  // 没有找到符合条件的路径，返回-1
}

// 主函数
int main()
{
    int x, y, tarx, tary;
    scanf("%d %d %d %d", &x, &y, &tarx, &tary);

    int step = bfs(x, y, tarx, tary);
    printf("%d", step);

    return 0;
}