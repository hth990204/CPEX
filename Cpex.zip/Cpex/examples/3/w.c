#include<stdio.h>
    void solve(){
        int n,a,b;
	scanf("%d %d %d",&n,&a,&b);
        if(n - a- b > 1){
		printf("YES\n");
        }
        else{
		printf("NO\n");
        }
    }
    int main(){
        int t;
	scanf("%d",&t);
        while(t--){
            solve();
        }
        return 0;
    }