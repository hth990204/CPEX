#include <stdio.h>

int main()
{
    int len;
    scanf("%d", &len);
    int arr[len];
    for (int i = 0; i < len; i++){
        scanf("%d", &arr[i]);
    }
    int target;
    scanf("%d", &target);

    int left = 0, right = len-1, res = -1;
    while(left <= right)
    {
        int mid = (left + right) / 2;

        if(target == arr[mid])
        {
            res = mid;
            break;
        }
        else if(target < arr[mid])
        {
            right = mid - 1; // 修改搜索区间的右端点
        }
        else
        {
            left = mid + 1; // 修改搜索区间的左端点
        }
    }
    printf("%d", res);

    return 0;
}