with open('initial.txt', 'r') as f1, open('bp.txt', 'r') as f2:
    # 读取两个文件的行
    lines1 = set(f1.readlines())
    lines2 = set(f2.readlines())

# 求出file1.txt中有，但file2.txt中没有的行
diff1 = lines1 - lines2
with open('diff1.txt', 'w') as f:
    for i in diff1:
        f.write(i)

diff2 = lines2 - lines1
with open('diff2.txt', 'w') as f:
    for i in diff2:
        f.write(i)
