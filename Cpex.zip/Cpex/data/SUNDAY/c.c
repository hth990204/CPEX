#include <stdio.h>

int main() {
    int t;
    scanf("%d",&t);
    int n;
    int a[100];
    while(t--){
        scanf("%d",&n);
        int count=0;
        for(int i=0;i<n;i++){
            scanf("%d",&a[i]);

        if((a[i]!=6)&&(a[i]%7!=0)&&(a[i]!=13)&&(a[i]!=20)&&(a[i]!=27)){
            count++;
        }
        }
        printf("%d\n",(count+8));
    }

	return 0;
}

//https://www.codechef.com/problems/SUNDAY?tab=statement