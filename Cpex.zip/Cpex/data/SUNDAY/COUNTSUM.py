with open('mark', 'r') as f:
    data = f.read()


data = data[1:-1]
print(data)
data_list = data.split(', ')
print(len(data_list))