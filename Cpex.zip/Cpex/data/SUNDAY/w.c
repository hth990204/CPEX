#include <stdio.h>

int main(void)
{
    int t;
    scanf("%d",&t);
    int n;
    int a[100];
    while(t--)
    {
        int count=0;
        scanf("%d",&n);
        for(int i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
            if((a[i]!=6)&&(a[i]!=0)&&(a[i]!=13)&&(a[i]!=20)&&(a[i]!=27))
        {
            count++;
        }
     }
}
}
