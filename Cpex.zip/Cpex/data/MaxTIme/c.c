#include <stdio.h>


int main()
{
    int n;
    scanf("%d", &n);

    int logs[n][2];
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &logs[i][0], &logs[i][1]);
    }

    int max = logs[0][1];
    int maxId = logs[0][0];
    for (int i = 0; i < n - 1; i++) {
        if (logs[i + 1][1] - logs[i][1] > max) {
            max = logs[i + 1][1] - logs[i][1];
            maxId = logs[i + 1][0];
        }
        if (logs[i + 1][1] - logs[i][1] == max) {
            if (logs[i + 1][0] < maxId) {
                maxId = logs[i + 1][0];
            }
        }
    }

    printf("%d", maxId);

    return 0;
}