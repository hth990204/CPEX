#include <stdio.h>

int main(void) {
	// your code goes here
	int t;
	scanf("%d",&t);
	while(t--){
	   int num=0, ct=0, rem=0;
	   scanf("%d",&num);
	   while(num!=0){
	       rem = num%10;
	       if(rem==4){
	           ct++;
	       }
	       num/=10;
	   }
	   printf("%d\n",ct);
	}
	return 0;
}
