#include <stdio.h>

int main(void) {
    int t,x,c=0;
    scanf("%d",&t);
    while(t){
        scanf("%d",&x);
        while(x>0){
            if(x%10==4){
                c++;
            }
            x/=10;
        }
        printf("%d\n",c);
        t--;
    }
	// your code goes here
	return 0;
}

