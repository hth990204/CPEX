#include <stdio.h>

int main(void) {
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int k;
        scanf("%d",&k);
        int c=0;
        while(k--)
        {
            if((k)%2==0)
            {
                c+=3;
            }
            else
            {
                c--;
            }
        }
        printf("%d\n",c);
    }
	return 0;
}

