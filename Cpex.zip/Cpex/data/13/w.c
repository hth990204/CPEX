#include <stdio.h>

int main(void) {
	int t;
	scanf("%d", &t);

	while(t--){
	    long test , nmax, nsum, n, nf=0 ;
	    scanf("%d %d %d", &test , &nmax, &nsum);
	    n = nsum;

	    for (int i = 1; i<=test ; i++){
	        if (n >= nmax){
	            n = n -nmax;

	            nf += (nmax*nmax);
	        }
	        else{
	            nf+= n*n;
	            break;
	        }
	    }
	    printf("%ld\n", nf);
	}
	return 0;
}
