#include <stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int a,b,c;
        scanf("%d %d %d",&a,&b,&c);
        int n=0,m=1;
        while(m<=a && c!=0)
        {
            if(c>=b)
            {
                n=n+(b*b);
                c=c-b;
            }
            else
            {
                n=n+(c*c);
                c=0;
            }
            m++;
        }
        printf("%d\n",n);

    }
    return 0;
}