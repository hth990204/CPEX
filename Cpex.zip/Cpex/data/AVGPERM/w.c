#include <stdio.h>

int main() {

 int t;
 scanf("%d",&t);
 while(t--)
 {
     int n;
     scanf("%d",&n);
     if(n%2==0)
     {
         for(int i=n-1;i>0;i--)
         {
             printf("%d ",i);
         }
         printf("%d",n);
     }
     else
     {
        for(int i=n;i>0;i--)
         {
             printf("%d ",i);
         }
     }
     printf("\n");
 }

	return 0;
}

