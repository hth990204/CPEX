#include <stdio.h>
//AVGPERM
int main(void)
{
    int t;
    scanf("%d",&t);

    int n;
    while(t--)
    {
        scanf("%d",&n);
        if(n%2==0)
        {
          for(int i=n;i>1;i--)
            {
                printf("%d ",i);
                i--;
            }
          for(int i=1;i<n;i++)
            {
              printf("%d ",i);
              i++;
            }
        }
        else
        {
            for(int i=n;i>=1;i--)
            {
                printf("%d ",i);
                i--;
            }
          for(int i=2;i<n;i++)
            {
              printf("%d ",i);
              i++;
            }
        }



        printf("\n");
    }
	// your code goes here
	return 0;
}

