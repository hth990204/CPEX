#include <stdio.h>
// https://www.codechef.com/problems/MISSP?tab=submissions   MISSP
int main(void) {
	// your code goes here
	int t, i,j,n, cnt,m;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	    scanf("%d",&n);
	    int arr[n],b[n];
	    for(j=0;j<n;j++)
	    {
	        scanf("%d",&arr[j]);
	    }
	    for(m=0;m<n;m++)
	    {
	        cnt=0;
	        for(j=0;j<n;j++)
	        {
	            if(arr[m]==arr[j])
	              cnt++;
	        }
	        b[m]=cnt;
	    }
	    for(m=0;m<n;m++)
	    {
	        if((b[m]%2)!=0)
	        {
	          printf("%d\n",arr[m]);
	          break;
	        }
	    }

	}
	return 0;
}
