#include <stdio.h>

int main(void) {
	// your code goes here
	int t;
	scanf("%d",&t);
	while(t--)
	{
	    int  n;
	    scanf("%d",&n);
	   int  i,a[20],j,c=0,x=0;
	    for(i=0;i<n;i++)
	    scanf("%d",&a[i]);
	    for(j=0;j<n;j++)
	    {
	        for(i=0;i<n;i++)
	        {
	            if (a[j]==a[i])
	            c=c+1;


	       if(c>x)
	       {
	       x=c;
	        }
	        }


	}printf("%d\n",n-x);

	}
	return 0;
}

