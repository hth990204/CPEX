#include<stdio.h>

//两个升序数组合并成一个
int main() {
    int len1, len2;
    scanf("%d", &len1);
    scanf("%d", &len2);
	int arr1[len1];
	int arr2[len2];
	for (int i = 0; i < len1; i++) {
	    scanf("%d", &arr1[i]);
	}
	for (int i = 0; i < len2; i++) {
	    scanf("%d", &arr2[i]);
	}
	int res[len1 + len2];
	int i=0, j=0, k=0;
	while (i < len1 && j < len2) {
		if (arr1[i] < arr2[j]) {
			res[k++] = arr1[i++]; //等价于  z[k[ = x [i];   k++;  i++;
 		} else {
			res[k++] = arr2[j++];
		}
	}
	//如果其中一个数组还有剩余，则按顺序依次存入
	while (len1 > i) {
		res[k++] = arr1[i++];
	}
	while (len2 > j) {
		res[k++] = arr2[j++];
	}

	printf("\n合并后的新数组c：");
	for (i = 0; i < len1 + len2; i++) {
		printf("%d ", res[i]);
	}
}
