#include <stdio.h>

int main(void) {
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int a,b,x,y;
        scanf("%d %d %d %d",&a,&b,&x,&y);
        if(a==b &&  x==y){
            printf("2\n");
        }
        if(a==b==x==y){
            printf("0\n");
        }
        if(a==x || b==y){
            printf("1\n");
        }
        else{
            printf("%d\n",(x-a)+1);
        }
    }
	// your code goes here
	return 0;
}
