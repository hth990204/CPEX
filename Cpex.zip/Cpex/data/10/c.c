#include <stdio.h>

int main(void) {
	int n,a,b,p,q;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
	    scanf("%d %d %d %d",&a,&b,&p,&q);
	    if(a==p && b==q){
	        printf("%d\n",0);
	    }
	    else if(((a+b)%2==0 && (p+q)%2==0)||((a+b)%2!=0)&&(p+q)%2!=0){
	        printf("%d\n",2);
	    }
	    else{
	        printf("%d\n",1);
	    }
	}
	return 0;
}